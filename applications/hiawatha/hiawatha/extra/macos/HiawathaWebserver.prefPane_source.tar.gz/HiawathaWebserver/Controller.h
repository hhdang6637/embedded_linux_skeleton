//
//  Controller.h
//  HiawathaWebserver
//
//  Created by Hugo Leisink on 6/9/08.
//  Copyright 2008 Hugo Leisink. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface Controller : NSObject {
	IBOutlet NSButtonCell *button;
}
- (IBAction)controlHiawathaWebserver:(id)sender;

@end
