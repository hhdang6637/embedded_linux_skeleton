//
//  HiawathaWebserverPref.h
//  HiawathaWebserver
//
//  Created by Hugo Leisink on 6/9/08.
//  Copyright (c) 2008 Hugo Leisink. All rights reserved.
//

#import <PreferencePanes/PreferencePanes.h>


@interface HiawathaWebserverPref : NSPreferencePane 
{

}

- (void) mainViewDidLoad;

@end
